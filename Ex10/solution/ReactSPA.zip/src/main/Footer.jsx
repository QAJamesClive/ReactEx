import React from 'react';

const Footer = () => {
    return (
        <footer>
            Made for fans by a fan
        </footer>
    );
}

export default Footer;
