import React from 'react';

const Title = () => {
  return (
    <div className="top-bar-title">
        <h1>a STAR WARS Fansite</h1>
    </div>
  );
}

export default Title;
