import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(<App title="Your Google Map Locations" />, document.getElementById('root'));
